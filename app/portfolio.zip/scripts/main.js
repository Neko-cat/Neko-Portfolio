$(document).ready(function(){

	// Help properly set the body width value.
	var $numberOfSlides = 3;

	/*
	* 	Set viewport width and height to each slide.
	* 		Yep that's dirty jQuery
	*/
	$('#slide1').css('width', $(window).width());
	$('#slide1').css('height', $(window).height());
	$('#slide2').css('width', $(window).width());
	$('#slide2').css('height', $(window).height());
	$('#slide3').css('width', $(window).width());
	$('#slide3').css('height', $(window).height());
	$('body').css('width', $(window).width() *$numberOfSlides);

		// Do the same on window resize
	$(window).resize(function() {
		$("#test").text("Largeur viewport = " + $(window).width() + "Hauteur du viewport = " + $(window).height() );
		$('#slide1').css('width', $(window).width());
		$('#slide1').css('height', $(window).height());
		$('#slide2').css('width', $(window).width());
		$('#slide2').css('height', $(window).height());
		$('#slide3').css('width', $(window).width());
		$('#slide3').css('height', $(window).height());
		$('body').css('width', $(window).width() *$numberOfSlides);
	});

	/*
	*	Bandelette opacity
	*/
	$('#bandelette').hover(function(){
		$('#opacity').stop().fadeTo('slow', 0.8);
	}, function() {
		$('#opacity').stop().fadeTo('slow', 0.6);
	});

	/*
	* Link
	*/
		// link animation
	$('#design').hover(function(){
		$('#design>.rond').addClass('red');
	}, function(){
		$('#design>.rond').removeClass('red');
	});
	$('#code').hover(function(){
		$('#code>.rond').addClass('red');
	}, function(){
		$('#code>.rond').removeClass('red');
	});
	$('#photos').hover(function(){
		$('#photos>.rond').addClass('red');
	}, function(){
		$('#photos>.rond').removeClass('red');
	});

		// On clicked link
	$('#toRight').click(function(){
		$(this).stop().scrollLeft( 1600 );
	});

	/*
	* pixelart animation
	*/
	$('.pixel').mouseenter(function(){
		$(this).fadeTo('fast', 0.4);
	});
	$('.pixel').mouseleave(function(){
		$(this).fadeTo('fast', 1);
	});
	/*
	*	Faire aparaitre une boite après le défillement de la première slide.
	*/
});
	// body background slideshow
$.backstretch([
	'images/bg.jpg',
	'images/cat.jpg'
], {
	fade: 2000,
	duration: 5000
});
